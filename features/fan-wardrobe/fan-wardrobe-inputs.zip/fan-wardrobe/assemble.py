"""Join three five-second Pika shots at 24 fps with their generated stereo."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile


BIN = Path(sys.executable).parent


def probe(path):
    result = subprocess.check_output([BIN / "ffprobe", "-v", "error", "-show_streams", "-of", "json", path])
    return json.loads(result)["streams"]


def frame_hashes(path):
    result = subprocess.check_output([BIN / "ffmpeg", "-v", "error", "-nostdin", "-xerror", "-i", path,
        "-map", "0:v:0", "-c:v", "rawvideo", "-pix_fmt", "yuv420p", "-f", "framehash", "-"], text=True)
    return [row.rsplit(",", 1)[-1].strip() for row in result.splitlines() if not row.startswith("#")]


def record(path):
    with path.open("rb") as stream:
        return dict(path=str(path.resolve()), bytes=path.stat().st_size, sha256=hashlib.file_digest(stream, "sha256").hexdigest())


def assemble(shots, output):
    if output.exists() or output.with_suffix(".edit.json").exists():
        raise FileExistsError(output)
    expected = []
    for shot in shots:
        video, audio = probe(shot)
        assert video["codec_name"] == "h264" and video["avg_frame_rate"] == "24/1"
        assert int(video["nb_frames"]) == 120 and float(video["duration"]) == 5.0
        assert audio["channels"] == 2 and audio["sample_rate"] == "32000"
        expected.extend(frame_hashes(shot))

    with tempfile.TemporaryDirectory() as folder:
        temporary = Path(folder)
        for index, shot in enumerate(shots):
            (temporary / f"shot{index}.mp4").symlink_to(shot.resolve())
        listing = temporary / "shots.ffconcat"
        listing.write_text("ffconcat version 1.0\n" + "".join(f"file shot{i}.mp4\nduration 5\n" for i in range(3)))
        # Keep frame zero at time zero when the concat input also has AAC encoder priming.
        command = [BIN / "ffmpeg", "-v", "error", "-nostdin", "-xerror", "-n", "-copyts", "-f", "concat", "-safe", "1", "-i", listing]
        filters = []
        for i, shot in enumerate(shots):
            command.extend(["-i", shot])
            # Very short fades either side of a cut prevent clicks between generated clips.
            end_fade = 0.12 if i == 2 else 0.012
            filters.append(f"[{i+1}:a:0]atrim=end_sample=160000,asetpts=PTS-STARTPTS,"
                f"afade=t=in:d=0.012,afade=t=out:st={5-end_fade}:d={end_fade}[a{i}]")
        filters.append("[a0][a1][a2]concat=n=3:v=0:a=1[a]")
        command.extend(["-filter_complex", ";".join(filters), "-map", "0:v:0", "-map", "[a]",
            "-c:v", "copy", "-c:a", "aac", "-ar", "32000", "-ac", "2", "-b:a", "192k",
            "-movflags", "+faststart", output])
        subprocess.run(command, check=True)

    video, audio = probe(output)
    actual = frame_hashes(output)
    assert actual == expected and len(actual) == 360
    assert video["start_pts"] == audio["start_pts"] == 0
    assert video["avg_frame_rate"] == "24/1" and float(video["duration"]) == float(audio["duration"]) == 15.0
    evidence = dict(output=record(output), shots=[record(p) for p in shots], frames=len(actual),
        source_pixels_preserved=True, cuts_seconds=[5.0, 10.0],
        audio="The three original stereo tracks in order, with 12 ms fades at the cuts and 120 ms at the ending.")
    with output.with_suffix(".edit.json").open("x") as stream:
        json.dump(evidence, stream, indent=2)
        stream.write("\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    parser.add_argument("shots", nargs=3, type=Path)
    args = parser.parse_args()
    assemble(args.shots, args.output)
