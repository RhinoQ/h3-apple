"""Assemble Wind It Up at native resolution with the original generated audio."""
import json
from pathlib import Path
import subprocess
import sys


def main():
    if len(sys.argv) != 2:
        raise SystemExit("Usage: python assemble.py wind-it-up.mp4")
    folder = Path(__file__).resolve().parent
    edit = json.loads((folder / "edit.json").read_text())
    ffmpeg = Path(sys.executable).parent / "ffmpeg"
    command = [ffmpeg, "-hide_banner", "-v", "error", "-nostdin", "-n"]
    filters = []
    for i, shot in enumerate(edit["shots"]):
        command.extend(["-i", folder / shot["file"]])
        first, end = shot["firstFrame"], shot["endFrame"]
        length = (end - first) / 24
        fade_out = 0.24 if i == 2 else 0.026
        filters.append(f"[{i}:v]trim=start_frame={first}:end_frame={end},setpts=PTS-STARTPTS,setsar=1[v{i}]")
        filters.append(f"[{i}:a]atrim=start={first/24:.9f}:end={end/24:.9f},asetpts=PTS-STARTPTS,"
                       f"afade=t=in:st=0:d=0.012,afade=t=out:st={length-fade_out:.9f}:d={fade_out}[a{i}]")
    command.extend(["-loop", "1", "-framerate", "24", "-i", folder / "end-title.png"])
    filters.extend([
        f"[3:v]format=rgba,fade=t=in:st={edit['titleStartsAt']}:d=0.32:alpha=1[title]",
        "[v2][title]overlay=shortest=1[v2t]",
        "[v0][a0][v1][a1][v2t][a2]concat=n=3:v=1:a=1[v][a]",
    ])
    command.extend(["-filter_complex", ";".join(filters), "-map", "[v]", "-map", "[a]",
                    "-c:v", "libx264", "-preset", "slow", "-crf", "18", "-maxrate", "5M", "-bufsize", "4M",
                    "-pix_fmt", "yuv420p",
                    "-c:a", "aac", "-ar", "32000", "-b:a", "192k", "-movflags", "+faststart",
                    "-map_metadata", "-1", "-metadata", "title=Wind It Up · h3-apple 0.9.0",
                    Path(sys.argv[1]).resolve()])
    subprocess.run(command, check=True)


if __name__ == "__main__":
    main()
