"""Small commands for preparing H3 and generating videos from images."""

import argparse
from dataclasses import asdict
import json
import sys

from .api import DownloadApprovalRequired, generate, resolve


def progress(event):
    if event.get("phase") == "model_plan":
        line = (f"Download: {event['download_bytes'] / 10**9:.2f} GB; "
                f"additional disk required: {event['additional_disk_bytes'] / 10**9:.2f} GB")
    else:
        line = event.get("message") or event.get("phase", "preparing").replace("_", " ").capitalize()
        if event.get("file"):
            line += ": " + event["file"]
    print(line, file=sys.stderr, flush=True)


def parser():
    from . import __version__
    top = argparse.ArgumentParser(prog="h3", description="Turn reference images and a prompt into video with stereo audio.")
    top.add_argument("--version", action="version", version=f"h3-apple {__version__}")
    commands = top.add_subparsers(dest="command", required=True)
    for name in ("generate", "resolve"):
        command = commands.add_parser(name, help="Generate a video" if name == "generate" else "Check inputs without generating")
        prompts = command.add_mutually_exclusive_group(required=True)
        prompts.add_argument("--prompt")
        prompts.add_argument("--prompt-file")
        command.add_argument("--image", action="append", required=True, dest="reference_images",
                             help="Reference image; repeat in picture-number order (1–9)")
        command.add_argument("--duration", type=float, default=15, help="5–15 seconds (default: 15)")
        command.add_argument("--resolution", choices=("544p", "576p", "768p"), default="576p",
                             help="Sampling resolution; 544p requires --x2; 768p excludes --x2 (default: 576p)")
        command.add_argument("--x2", action="store_true", help="Double output width and height for 544p or 576p sampling (requires VSA dependencies)")
        command.add_argument("--aspect-ratio", choices=("16:9", "9:16"), default="16:9")
        command.add_argument("--seed", type=int)
        command.add_argument("--mode", choices=("VSA", "SOL"), default="VSA",
                             help="Generation mode (default: VSA)")
        if name == "generate":
            command.add_argument("--output", help="New .mp4 path (default: unique folder in runs/)")
            command.add_argument("--model-dir")
            command.add_argument("--x2-model-dir", help="Optional X2 model directory (separate from generation models)")
            command.add_argument("--diagnostics", action="store_true", help="Keep working files for debugging")
            command.add_argument("--timeout", type=float, default=7200)
            command.add_argument("--no-progress", action="store_true")
            command.add_argument("--allow-large-download", action="store_true",
                                 help="Confirm first-run model downloads exceeding 20 GB")
    prepare = commands.add_parser("prepare", help="Download or reuse models and prepare H3 once")
    prepare.add_argument("--model-dir")
    prepare.add_argument("--mode", choices=("VSA", "SOL"), default="VSA")
    prepare.add_argument("--reuse-dir", action="append", default=[], dest="reuse_dirs",
                         help="Reuse a source snapshot or an existing H3 model installation")
    prepare.add_argument("--plan", action="store_true", help="Check download and disk requirements only")
    prepare.add_argument("--allow-large-download", action="store_true", help="Confirm downloads exceeding 20 GB")
    for name in ("doctor", "verify"):
        command = commands.add_parser(name, help="Check installation" if name == "doctor" else "Verify all model checksums")
        command.add_argument("--model-dir")
        command.add_argument("--mode", choices=("VSA", "SOL"), default="VSA")
    faces = commands.add_parser("enhance-faces", help="Optionally enhance small faces in an existing H3 video")
    faces.add_argument("--input", required=True, dest="video")
    faces.add_argument("--output")
    faces.add_argument("--model-dir", help="Optional face model directory (separate from H3 generation models)")
    faces.add_argument("--diagnostics", action="store_true")
    faces.add_argument("--timeout", type=float, default=7200)
    prepare_faces = commands.add_parser("prepare-faces", help="Prepare the optional 7.08 GB face models")
    prepare_faces.add_argument("--model-dir")
    prepare_faces.add_argument("--reuse-dir", action="append", default=[], dest="reuse_dirs")
    prepare_faces.add_argument("--plan", action="store_true")
    prepare_x2 = commands.add_parser("prepare-x2", help="Prepare the optional 5.25 GB X2 decoder")
    prepare_x2.add_argument("--model-dir")
    prepare_x2.add_argument("--reuse-dir", action="append", default=[], dest="reuse_dirs")
    prepare_x2.add_argument("--plan", action="store_true")
    return top


def main(argv=None):
    args = vars(parser().parse_args(argv))
    command = args.pop("command")
    try:
        if command == "generate":
            from .progress import ProgressBar
            with ProgressBar(enabled=not args.pop("no_progress")) as display:
                try:
                    result = asdict(generate(**args, on_progress=display))
                except DownloadApprovalRequired as error:
                    if not sys.stdin.isatty():
                        raise
                    print(f"\n{error}", file=sys.stderr)
                    print("Download these model files? [y/N] ", end="", file=sys.stderr, flush=True)
                    if sys.stdin.readline().strip().lower() not in ("y", "yes"):
                        raise RuntimeError("Model download cancelled. No model files were downloaded.") from None
                    args["allow_large_download"] = True
                    result = asdict(generate(**args, on_progress=display))
        elif command == "resolve":
            result = resolve(**args).to_dict()
        elif command == "doctor":
            from .host import doctor
            result = doctor(**args)
            print(json.dumps(result, indent=2, default=str))
            return 0 if result["ready"] else 1
        elif command == "verify":
            if args["mode"] == "VSA":
                from .vsa_assets import load_assets
            else:
                from .assets import load_assets
            data = load_assets(args["model_dir"], verify=True)
            result = dict(status="verified", directory=data["directory"], identity=data["identity"])
        elif command == "enhance-faces":
            from .faces.api import enhance_faces
            result = asdict(enhance_faces(**args, on_progress=progress))
        elif command == "prepare-faces":
            from .faces.assets import plan, prepare
            show_plan = args.pop("plan")
            result = plan(**args) if show_plan else prepare(**args, on_progress=progress)
        elif command == "prepare-x2":
            from .x2_assets import plan, prepare
            show_plan = args.pop("plan")
            result = plan(**args) if show_plan else prepare(**args, on_progress=progress)
        else:
            if args.pop("mode") == "VSA":
                from .vsa_preparation import plan, prepare, LIMIT
            else:
                from .preparation import plan, prepare, LIMIT
            show_plan = args.pop("plan")
            allowed = args.pop("allow_large_download")
            spec = plan(**args, progress=progress)
            progress(dict(spec, phase="model_plan"))
            if show_plan:
                result = {k: v for k, v in spec.items() if k not in ("groups", "prepared")}
            else:
                if spec["download_bytes"] > LIMIT and not allowed and sys.stdin.isatty():
                    allowed = input("Download these model files? [y/N] ").strip().lower() in ("y", "yes")
                data = prepare(spec, allow_large_download=allowed, progress=progress)
                result = dict(status="ready", directory=data["directory"], identity=data["identity"])
        print(json.dumps(result, indent=2, ensure_ascii=False, default=str))
        return 0
    except KeyboardInterrupt:
        print("Cancelled. Working files were preserved.", file=sys.stderr)
        return 130
    except (OSError, ValueError, RuntimeError, TimeoutError) as error:
        print(f"h3: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
